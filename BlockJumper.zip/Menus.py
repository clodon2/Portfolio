import pygame as pg
import pygame.freetype
from pygame.locals import *
import DatabaseStuff
pg.init()
pg.freetype.init()

buttonfont = pg.freetype.Font("Other/RandomNine.otf", 40)
titlefont = pg.freetype.Font("Other/RandomNine.otf", 70)
inputfont = pg.freetype.Font("Other/Cano-VGMwz.ttf", 28)

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
white = (255, 255, 255)
red = (200, 0, 0)
black = (0, 0, 0)
blue = (0, 0, 200)
clock = pg.time.Clock()
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))


class Button(pg.sprite.Sprite):
    def __init__(self, text, location):
        super(Button, self).__init__()
        self.surf = pg.surface.Surface((250, 100))
        self.surf.fill((50, 50, 255))
        if text.count(" ") > 0:
            text1 = text[:text.index(" ")]
            text2 = text[text.index(" "):]
            text1, textrect1 = buttonfont.render(text1, (255, 255, 255))
            text2, textrect2 = buttonfont.render(text2, (255, 255, 255))
            self.surf.blit(text1, ((self.surf.get_width()/2 - textrect1.width/2), (self.surf.get_height()/2 - textrect1.height)))
            self.surf.blit(text2, ((self.surf.get_width()/2 - textrect2.width/2 - 8), (self.surf.get_height()/2)))
        else:
            text, textrect = buttonfont.render(text, (255, 255, 255))
            self.surf.blit(text, ((self.surf.get_width()/2 - textrect.width/2), (self.surf.get_height()/2 - textrect.height/2)))
        self.rect = self.surf.get_rect(
            center=(
                    location,
                    ))


class Block(pg.sprite.Sprite):
    def __init__(self, location):
        super(Block, self).__init__()
        self.surf = pg.surface.Surface((300, 35))
        self.surf.fill(white)
        self.rect = self.surf.get_rect(center=location)


def MainMenu():
    inmenu = True
    username = ""
    screen.fill((20, 20, 200))
    Input = Block((400, 250))
    validcharacters = "qwertyuiopasdfghjklzxcvbnm QWERTYUIOPASDFGHJKLZXCVBNM1234567890"
    StartGame = Button("Start Game", (SCREEN_WIDTH/2, 400))
    welcome, welcomerect = titlefont.render("Block Jumper")
    nameprompt, namepr = buttonfont.render("Username:", white)
    Button_Sprites = pg.sprite.Group()
    Button_Sprites.add(StartGame, Input)
    while inmenu:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                return False

            if event.type == KEYDOWN:
                if event.key == K_BACKSPACE:
                    # deletes the last character
                    username = username[:-1]
                else:
                    # adds character to username
                    if event.unicode in validcharacters:
                        username += event.unicode
                # keeps username within 10 characters
                username = username[:10]

            if pg.mouse.get_pressed(num_buttons=3)[0]:
                if pg.Rect.collidepoint(StartGame.rect, pg.mouse.get_pos()):
                    DatabaseStuff.insertPlayer(username)
                    return "Start Game", username

        for entity in Button_Sprites:
            screen.blit(entity.surf, entity.rect)

        user, userect = inputfont.render(username, black)

        userect.clamp_ip(Input.rect)
        userect.move_ip((5, 5))

        screen.blit(welcome, ((SCREEN_WIDTH/2 - welcomerect.width/2), 30))
        screen.blit(nameprompt, (SCREEN_WIDTH/2 - namepr.width/2 + 5, 170))
        screen.blit(user, userect)

        pg.display.flip()
        clock.tick(30)


def GameOver(username):
    inmenu = True
    screen.fill((20, 20, 200))
    Retry = Button("Retry", (400, 200))
    BackToMenu = Button("Main Menu", (400, 400))
    deathmessage, deathmrect = titlefont.render("You Died")
    Button_Sprites = pg.sprite.Group()
    Button_Sprites.add(Retry, BackToMenu)
    while inmenu:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                return False

            if pg.mouse.get_pressed(num_buttons=3)[0]:
                if pg.Rect.collidepoint(Retry.rect, pg.mouse.get_pos()):
                    return "Retry", username
                if pg.Rect.collidepoint(BackToMenu.rect, pg.mouse.get_pos()):
                    return "Main Menu", username

        for entity in Button_Sprites:
            screen.blit(entity.surf, entity.rect)

        screen.blit(deathmessage, ((SCREEN_WIDTH/2 - deathmrect.width/2), 30))

        pg.display.flip()
        clock.tick(30)
