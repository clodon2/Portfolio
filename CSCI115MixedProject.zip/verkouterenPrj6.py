"""
Corey Verkouteren
CSCI 115 Van Camp
12/5/23-12/10/23
Project 6

Description:
    This program displays an image selected by the user, can change red pixels
    in the image to green, display the next file, and display the time and date.

Functions:
getDateTime - connect to time.nist.gov API and retrive raw time/date info,
    return results
getDistance - used in color change, gets rgb value difference of 2 colors,
    return rgb color distance
pixelColor - used in color change, if pixel is red return pure red and
    equivalent green color, otherwise return False
changePixels - transform red pixels within a threshold to equivalent green
    pixels, changes image directly

Classes:
DisplayWindow - main program window, holds pretty much everything

Methods:
hideElement - hides a given element of a window (label, button, etc.)
showElement - reveal/show a given element of a window (label, button, etc.)
imageInfoHide - hides the imageInfo label, which shows file name and size info
    for the loaded image
imageInfoShow - hides the imageInfo label, which shows file name and size info
    for the loaded image
loadImage - load image in the filepath of self.fileInput's text into image
    parameter of self.imageLabel, show message box if error
redToGreen - convert red pixels in self.imageLabel's image to green pixels,
    uses changePixels, show message box if no image/error
nextFile - shownext /rotate through images in the ./images/ directory within
    the program directory, shpw message box if error
timeDisplay - if self.timeCheck checkbox is checked, display the time from
    getDateTime to self.timeOutput, otherwise clear self.timeOutput,
    show messagebox if error
dateDisplay - if self.dateCheck checkbox is checked, display the date from
    getDateTime to self.dateOutput, otherwise clear self.dateOutput,
    show messagebox if error
clearTime - clears text from self.timeOutput
clearDate - clears text from self.dateOutput

Variables:
BUFFERSIZE - size of buffer to use when doing API connection
IMAGEINFOFONT - font info for self.imageInfo
TEXTFIELDFONT - font info for ALL text fields

timeConnection - socket/network connection to time.nist.gov
dateTime - decoded API result form timeConnection

distance - distance between 2 RGB colors

pixelType - tuple of main pixel color and conversion color (uses pixelColor)
pixelDif - distance between main pixel color and pixel color (uses getDistance)

self.imageDir - directory to pull images from, used in nextFile
PANELS - any self.__Panel contains the elements related to that category, ease
    of organization
self.imageLabel - label that holds the loaded image
self.imageInfo - label (hidden unless self.imageLabel hovered) that shows
    self.imageLabel's image name and size
self.time/dateCheck - checkbox that determines display of self.time/dateOutput
self.time/dateOutput - text field displaying date/time, cleared with f4/f5 when
    in focus
BUTTONS - run indicated methods
self.fileInput - name of file to load/is loaded in self.imageLabel


"""


from breezypythongui import EasyFrame
from tkinter import PhotoImage
import os
from socket import *
from codecs import decode


BUFFERSIZE = 1024
IMAGEINFOFONT = ("Impact", 20)
TEXTFIELDFONT = ("Comfortaa", 10)


def getDateTime():
    timeConnection = socket(AF_INET, SOCK_STREAM)
    timeConnection.connect(("time.nist.gov", 13))
    dateTime = decode(timeConnection.recv(BUFFERSIZE), "utf-8")
    timeConnection.close()
    return dateTime


def getDistance(color1, color2):
    # calculate an averaged distance one color is from another
    distance = (((color1[0] - color2[0]) ** 2) +
                ((color1[1] - color2[1]) ** 2) +
                ((color1[2] - color2[2]) ** 2)) ** (1/2)
    return distance


def pixelColor(rgb):
    # if more red than blue and green, return a red color and an equivalent
    # green color
    if rgb[0] > (rgb[1] + rgb[2])/2:
        return (255, 0, 0), (rgb[1], rgb[0], rgb[2])
    else:
        return False


def changePixels(image, threshold = 170):
    # iterate through pixels
    for y in range(image.height()):
        for x in range(image.width()):
            # get pixel rgb values
            pixelRGB = image.get(x, y)
            # get pixel color and color to change to
            # ([dominant color], [color to change to])
            pixelType = pixelColor(pixelRGB)
            # get relative distance of dominant color to actual color values
            if pixelType:
                pixelDif = getDistance(pixelRGB, pixelType[0])
                # if relative distance is more than threshold, convert pixel to
                # equivalent opposite
                if pixelDif <= threshold:
                    image.put("#%02x%02x%02x" % pixelType[1], (x, y))


class DisplayWindow(EasyFrame):
    def __init__(self):
        EasyFrame.__init__(self, title="Image Loader and Editor + Time Grabber")
        
        self.imageDir = "/images/"

        # set up image panel stuff
        self.imagePanel = self.addPanel(0, 0, rowspan=5, columnspan=1,
                                        background="dark blue")
        self.imagePanel.addLabel(text="The Current image:", row=0, column=0)
        self.imageLabel = self.imagePanel.addLabel(text="", row=1, column=0)
        # hover displayed image information
        self.imageInfo = self.imagePanel.addLabel(text="", row=2, column=0, sticky="N")
        self.imageInfo["text"] = f"{self.imageLabel['image']} \
{self.imageLabel['width']}x{self.imageLabel['height']}"
        self.imageInfo["font"] = IMAGEINFOFONT
        # hide label by default
        self.imageInfo.grid_remove()

        # mouse enters imageLabel element, show image information
        self.imageLabel.bind("<Enter>", lambda event: self.imageInfoShow())
        # mouse leaves imageLabel element, hide image information
        self.imageLabel.bind("<Leave>", lambda event: self.imageInfoHide())
        
        # set up time panel stuff
        self.timePanel = self.addPanel(0, 1, rowspan=4, columnspan=2,
                                       background="gray")
        self.timeCheck = self.timePanel.addCheckbutton(text="Display Current Time:",
                                                       row=0, column=0, sticky="NE")
        self.timeOutput = self.timePanel.addTextField(text="", row=1, column=0,
                                            state="readonly")
        self.timeOutput["font"] = TEXTFIELDFONT
        
        self.dateCheck = self.timePanel.addCheckbutton(text="Display Current Date:",
                                             row=2, column=0, sticky="NE")
        self.dateOutput = self.timePanel.addTextField(text="", row=3, column=0,
                                            state="readonly")
        self.dateOutput["font"] = TEXTFIELDFONT

        # if checkbox clicked, display/clear corresponding time/date info
        self.timeCheck.bind("<ButtonPress-1>", lambda event: self.timeDisplay())
        self.dateCheck.bind("<ButtonPress-1>", lambda event: self.dateDisplay())

        # clear time/date output if element in fcous and f4/5 clicked
        self.timeOutput.bind("<F4>", lambda event: self.clearTime())
        self.dateOutput.bind("<F5>", lambda event: self.clearDate())
        

        # button panel setup stuff
        self.buttonPanel = self.addPanel(5, 0, rowspan=1, columnspan=4,
                                         background="blue")
        self.loadButton = self.buttonPanel.addButton(text="Load a File", row=0, column=0,
                                         command=self.loadImage)
        self.changeButton = self.buttonPanel.addButton(text="Change Red to Green",
                                           row=0, column=1,
                                           command=self.redToGreen)
        self.nextButton = self.buttonPanel.addButton(text="Display Next File",
                                         row=0, column=2,
                                         command=self.nextFile)

        # file panel setup stuff
        self.loadPanel = self.addPanel(6, 0, rowspan=2, columnspan=3,
                                       background="light blue")
        self.loadPanel.addLabel(text="Enter the file name and press the 'Load a File' button",
                      row=0, column=0, sticky="N")
        self.fileInput = self.loadPanel.addTextField(text="./images/",
                                           row=1, column=0, width=40, sticky="N")
        self.fileInput["font"] = TEXTFIELDFONT


    # hides a window element
    def hideElement(self, element):
        element.grid_remove()


    # reveals a window element
    def showElement(self, element):
        element.grid()


    # hide image info label
    def imageInfoHide(self):
        self.hideElement(self.imageInfo)


    # show image info label
    def imageInfoShow(self):
        try:
            self.imageInfo["text"] = f"{self.image.cget('file')} \
    {self.image.width()}x{self.image.height()}"
            self.showElement(self.imageInfo)
        except:
            pass


    # load image based on path from self.fileInput
    def loadImage(self):
        try:
            # get filepath
            imageName = self.fileInput.get()
            self.image = PhotoImage(file=imageName)
            # load image into image label
            self.imageLabel["image"] = self.image
        except:
            self.messageBox(title="Error opening file",
                            message="Unable to find file")


    # convert red pixels of loaded image to green pixels
    def redToGreen(self):
        try:
            changePixels(self.image)
        except:
            self.messageBox(title="Error editing file",
                            message="Image not loaded or another error has occured")
        

    # load next file in directory
    def nextFile(self):
        # gets only image name, such as ./imagefolder/image.gif returns image.gif
        currentImage = self.fileInput.get().split("/")[-1:]
        currentImage = "".join(currentImage)
        # if there was an image loaded/inputted, continue from there
        if currentImage:
            # get full path to file directory
            fullPath = os.getcwd() + self.imageDir
            # get all images in directory
            imageList = os.listdir(fullPath)
            # current location in directory
            curIndex = imageList.index(currentImage)

            # next image to go to
            nextIndex = curIndex + 1
            if nextIndex >= len(imageList):
                nextIndex = 0

            nextImage = imageList[nextIndex]

        # if no image loaded/inputted, start at top of directory
        else:
            # get full path to directory
            fullPath = os.getcwd() + self.imageDir
            # list of all images in directory
            imageList = os.listdir(fullPath)

            nextImage = imageList[0]

        # show current image path in fileInput
        self.fileInput.setText("." + self.imageDir + nextImage)

        # load image into image label
        self.loadImage()


    def timeDisplay(self):
        # if checkbox not checked (checkbox is being changed to checked)
        if not self.timeCheck.isChecked():
            try:
                dateTimeInfo = getDateTime()
                # time data is 2nd, return value from dateTimeInfo is a string
                self.timeOutput.setText(dateTimeInfo.split()[2])
            except:
                self.messageBox(title="Error retrieving time",
                                message="There was an error retrieving the time from time.nist.gov")
        else:
            self.timeOutput.setText("")


    def dateDisplay(self):
        # if checkbox not checked (checkbox is being changed to checked)
        if not self.dateCheck.isChecked():
            try:
                dateTimeInfo = getDateTime()
                # if there is an error getting dateTimeInfo, it returns a denial
                # string, so we replace that with a message box
                if dateTimeInfo.split()[1] != "denied":
                    # time data is 1st, return value from dateTimeInfo is a string
                    self.dateOutput.setText(dateTimeInfo.split()[1])
                else:
                    self.messageBox(title="Error retrieving date",
                                    message="There was an error retrieving the date from time.nist.gov")
            except:
                self.messageBox(title="Error retrieving date",
                                message="There was an error retrieving the date from time.nist.gov")
        else:
            self.dateOutput.setText("")


    def clearTime(self):
        self.timeOutput.setText("")


    def clearDate(self):
        self.dateOutput.setText("")
    


if __name__ == "__main__":
    sampleWindow = DisplayWindow()
    sampleWindow.mainloop()
        
        
